# core
Blogger Template JetTheme<br/>
<br/>
JetTheme Versi 2.9 <a href='https://github.com/jettheme/core/archive/refs/heads/main.zip'>Download files</a><br/>
<a href='https://www.jettheme.com/p/change-log.html'>ChangeLog</a><br/>
<br/>
View <a href='https://jettheme-demo.blogspot.com/'>Demo</a><br/>
How to Install <a href='https://www.jettheme.com/2020/02/cara-instal-jettheme-di-blogger.html'>Click Here</a><br/>
How to Settings <a href='https://www.jettheme.com/2021/03/setting-template-jettheme.html'>Click Here</a><br/><br/>
Group Telegram <a href='https://t.me/jettheme_com'>t.me/jettheme_com</a><br/>
Buy a coffee to support jettheme developers <a href='https://saweria.co/jettheme'>saweria.co/jettheme</a>
