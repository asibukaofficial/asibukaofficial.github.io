/*
-----------------------------------------------
Blogger Template Style
Theme Name		: SEOFastBlogger
Description		: Responsive, SEO, Fast and Optimize Blogger Templates
Version			: 1.0
Author			: Gian MR
Author URL     	: http://www.gianmr.com/
Theme URL      	: http://www.gianmr.com/2016/02/seofastblogger-responsive-blogger-template.html
Created Date   	: Januari 19, 2016
License        	: http://www.gianmr.com/p/terms-of-use.html#template-license
----------------------------------------------- */

Tutorial konfigurasi:
http://www.gianmr.com/p/cara-konfigurasi-template-seofastblogger.html

Link download:
http://www.gianmr.com/2016/02/seofastblogger-responsive-blogger-template.html

Perhatian:
Jangan pernah menghapus link kredit untuk template free.
Jangan pernah klaim template ini sebagai milik anda, anda bebas untuk menyebarkan template ini dan memberi kepada teman atau klien anda, selama link kredit ke template aslinya tidak anda hapus.

Ingin menghapus link kredit silahkan anda beli versi pro nya. Cara pembelian template di kentooz:
http://www.bostheme.com/cara-melakukan-pembelian-tema-di-kentooz/

Semoga berkah template nya dan bermanfaat buat blog anda.

Salam Hangat...

Gian MR